לפרטים על התקנת ספריות, ראה: http://www.arduino.cc/en/Guide/Libraries
